package com.techhue.views;

public class Season {

  public static String valueOf(Season season) {
    return "January";
  }

}
