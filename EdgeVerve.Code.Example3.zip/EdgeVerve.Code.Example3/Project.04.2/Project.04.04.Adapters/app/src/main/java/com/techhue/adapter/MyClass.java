package com.techhue.adapter;

public class MyClass
{
    public String name;

    public MyClass(String name)
    {
        this.name = name;
    }
}
